#!/usr/bin/env python3
import os, sys
from redis import Redis
m=os.environ.get("MARKET","HONEY-EUR")
stream=os.environ.get("STREAM","signals:baseline")
group=os.environ.get("GROUP","trading_submitter")
payload={"market":m,"side":"buy","price":"1.23","size":"5.0","tp_pct":"0.008","sl_pct":"0.006","reason":"dry_probe"}
r=Redis.from_url("redis://127.0.0.1:6379/0",decode_responses=True)
try:
    r.xgroup_create(stream, group, id="$", mkstream=True)
except Exception as e:
    if "BUSYGROUP" not in str(e): print("xgroup_create warn:", e, file=sys.stderr)
xid=r.xadd(stream, payload, id="*")
print("XADD ->", xid, "(len=", r.xlen(stream), ")")
