#!/usr/bin/env bash
set -Eeuo pipefail
MARKET="${1:-HONEY-EUR}"
QUIET="${QUIET:-1}"
read_port(){ curl -s 127.0.0.1:9111/metrics | sed -n "s/^guard_port_assignment{market=\"${MARKET}\"} \([0-9][0-9]*\).*/\1/p" | tail -n1; }
PORT="$(read_port || true)"
if [[ -z "${PORT:-}" || "${PORT}" = "0" ]]; then PORT="$(awk -F= '/^PROM_PORT=/{print $2}' "/etc/trading/guard/${MARKET}.env" 2>/dev/null || true)"; fi
if [[ -z "${PORT:-}" || "${PORT}" = "0" ]]; then echo "[fix-one] Geen poort voor ${MARKET}"; exit 1; fi
systemctl stop trading-guard-reconciler.service || true; sleep 0.3
echo "PROM_PORT=${PORT}" > "/etc/trading/guard/${MARKET}.env"
systemctl stop "trading-guard@${MARKET}.service" 2>/dev/null || true
systemctl reset-failed "trading-guard@${MARKET}.service" 2>/dev/null || true
sleep 0.2
sudo -u trader /srv/trading/.venv/bin/python - <<'PY'
from redis import Redis; import os
r=Redis.from_url("redis://127.0.0.1:6379/0",decode_responses=True)
m=os.environ.get("MARKET","HONEY-EUR")
ks=set([f"lock:guard:{m}"])|set(r.keys(f"*{m}*lock*"))|set(r.keys(f"guard:*:{m}*lock*"))
for k in ks: r.delete(k)
print("locks cleared:",sorted(list(ks)))
PY
PIDS=$(ss -ltnp 2>/dev/null | awk -v P=":${PORT} " '$0 ~ P {print $NF}' | sed -E 's/.*pid=([0-9]+).*/\1/' | sort -u); if [ -n "${PIDS:-}" ]; then for pid in $PIDS; do kill "$pid" 2>/dev/null || true; done; fi
systemctl start "trading-guard@${MARKET}.service"
for i in $(seq 1 30); do code=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${PORT}/metrics" || true); [ "$code" = "200" ] && break; sleep 0.3; done
echo "${MARKET} :${PORT} -> ${code:-000}"
systemctl start trading-guard-reconciler.service || true
