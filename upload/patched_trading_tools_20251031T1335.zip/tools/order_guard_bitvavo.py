#!/usr/bin/env python3
import os, sys, time, json, logging, datetime as dt
from decimal import Decimal, ROUND_DOWN

import redis

REDIS_URL = os.getenv("REDIS_URL", "redis://127.0.0.1:6379/0")
ORDER_STREAM = os.getenv("ORDER_OUTBOX_STREAM", "orders:live")
GROUP = "trading_guard"
CONSUMER = "guard-1"

BITVAVO_API_KEY = os.getenv("BITVAVO_API_KEY")
BITVAVO_API_SECRET = os.getenv("BITVAVO_API_SECRET")
BITVAVO_REST_URL = os.getenv("BITVAVO_REST_URL", "https://api.bitvavo.com/v2")
BITVAVO_WS_URL = os.getenv("BITVAVO_WS_URL", "wss://ws.bitvavo.com/v2")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("guard")

try:
    from python_bitvavo_api.bitvavo import Bitvavo
except Exception as e:
    log.error("python_bitvavo_api niet geïnstalleerd: %s", e)
    sys.exit(1)

def now_iso(): 
    return dt.datetime.utcnow().replace(microsecond=0).isoformat()+"Z"

def ensure_group(r: redis.Redis, stream: str, group: str):
    try:
        r.xgroup_create(name=stream, groupname=group, id="$", mkstream=True)
        log.info("XGROUP CREATE %s %s", stream, group)
    except redis.exceptions.ResponseError as e:
        if "BUSYGROUP" in str(e):
            pass
        else:
            raise

def make_client():
    if not BITVAVO_API_KEY or not BITVAVO_API_SECRET:
        raise RuntimeError("BITVAVO_API_KEY/SECRET ontbreken voor guard")
    return Bitvavo({
        "APIKEY": BITVAVO_API_KEY,
        "APISECRET": BITVAVO_API_SECRET,
        "RESTURL": BITVAVO_REST_URL,
        "WSURL": BITVAVO_WS_URL,
        "ACCESSWINDOW": 10000
    })

def main():
    r = redis.Redis.from_url(REDIS_URL, decode_responses=True)
    ensure_group(r, ORDER_STREAM, GROUP)
    bv = make_client()
    log.info("Guard gestart | stream=%s group=%s consumer=%s", ORDER_STREAM, GROUP, CONSUMER)

    # Minimal placeholder: read orders and no-op (or later set TP/SL/Trail via SDK if needed)
    while True:
        try:
            resp = r.xreadgroup(GROUP, CONSUMER, {ORDER_STREAM: ">"}, count=10, block=5000)
            if not resp:
                continue
            for _stream, entries in resp:
                for msg_id, kv in entries:
                    # In een latere stap: bewaak open orders/positions en sluit op TP/SL/Trail
                    log.info("GUARD SEEN id=%s payload=%s", msg_id, json.dumps(kv))
                    r.xack(ORDER_STREAM, GROUP, msg_id)
        except Exception as e:
            log.error("guard loop error: %s", e)
            time.sleep(0.2)

if __name__ == "__main__":
    main()
