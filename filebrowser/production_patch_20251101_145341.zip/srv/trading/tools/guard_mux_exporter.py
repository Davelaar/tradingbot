#!/usr/bin/env python3
import re, time, threading, urllib.request
from wsgiref.simple_server import make_server
RECON_ADDR="http://127.0.0.1:9111/metrics"; LISTEN_HOST="0.0.0.0"; LISTEN_PORT=9120
HEADERS=[("Content-Type","text/plain; version=0.0.4; charset=utf-8")]
_map_lock=threading.Lock(); _portmap={}
_assign_re=re.compile(r'^guard_port_assignment\{market="([^"]+)"\}\s+([0-9]+(?:\.[0-9]+)?)\s*$')
def refresh_map():
    while True:
        try:
            with urllib.request.urlopen(RECON_ADDR, timeout=1.0) as r:
                body=r.read().decode("utf-8","ignore").splitlines()
            pm={}
            for line in body:
                m=_assign_re.match(line.strip())
                if m:
                    mk=m.group(1)
                    try: port=int(float(m.group(2)))
                    except ValueError: continue
                    pm[mk]=port
            with _map_lock: _portmap.clear(); _portmap.update(pm)
        except Exception: pass
        time.sleep(2.0)
def scrape_guard(mk,port):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/metrics", timeout=1.0) as r:
            return r.read().decode("utf-8","ignore"), None
    except Exception as e: return "", e
def app(env,start):
    p=env.get("PATH_INFO","/")
    if p=="/-/ready": start("200 OK",HEADERS); return [b"ok"]
    if p!="/metrics": start("404 Not Found", HEADERS); return [b"not found"]
    with _map_lock: mapping=dict(_portmap)
    lines=["# HELP guard_mux_targets Number of guard targets detected","# TYPE guard_mux_targets gauge",f"guard_mux_targets {len(mapping)}"]
    for mk,prt in mapping.items():
        body,err=scrape_guard(mk,prt)
        if err: lines.append(f'guard_mux_scrape_errors_total{{market="{mk}"}} 1')
        else:
            for ln in body.splitlines():
                if ln.startswith("guard_"): lines.append(ln)
    out="\n".join(lines)+"\n"; start("200 OK",HEADERS); return [out.encode("utf-8")]
if __name__=="__main__":
    t=threading.Thread(target=refresh_map,daemon=True); t.start()
    print(f"[guard-mux] listening on {LISTEN_HOST}:{LISTEN_PORT} — recon={RECON_ADDR}", flush=True)
    httpd=make_server(LISTEN_HOST,LISTEN_PORT,app); httpd.serve_forever()
