#!/usr/bin/env bash
set -Eeuo pipefail
QUIET="${QUIET:-1}"
MAP=$(curl -s 127.0.0.1:9111/metrics | sed -n 's/^guard_port_assignment{market="\([^"]\+\)"} \([0-9]\+\).*/\1 \2/p' | sort -u)
[ -z "${MAP}" ] && { echo "no mapping"; exit 0; }
systemctl stop trading-guard-reconciler.service || true; sleep 0.3
while read -r M P; do [ -z "$M" ] && continue; QUIET="${QUIET}" MARKET="$M" /srv/trading/tools/guard_fix_one.sh "$M" || true; done <<< "${MAP}"
systemctl start trading-guard-reconciler.service || true
PORTS=$(echo "${MAP}" | awk '{print $2}' | sort -nu); for p in ${PORTS}; do code=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${p}/metrics" || true); printf ":%s -> %s\n" "$p" "${code:-000}"; done
curl -s 127.0.0.1:9120/metrics | grep -E '^(guard_mux_targets|guard_mux_scrape_errors_total\{)' || true
